package com.minor.project.controller.advice;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.minor.project.exception.EntityExceptions;
import com.minor.project.response.ErrorMessage;

@RestControllerAdvice
public class BookControllerAdvice {

	//@Autowired
	//ObjectMapper objectMapper;
	
	@ExceptionHandler(value = {EntityExceptions.class})
	public ResponseEntity<ErrorMessage> catchBooksException(EntityExceptions exceptions){
		return new ResponseEntity<>(ErrorMessage.builder()
				.errorCode(exceptions.getExceptionCode().getErrorCode())
						.errorMessage(exceptions.getExceptionCode().getErrorMessage()).build(),exceptions.getExceptionCode().getStatus());
	}
	
}
