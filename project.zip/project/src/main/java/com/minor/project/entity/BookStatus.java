package com.minor.project.entity;

public enum BookStatus {

	AVAILABLE,
	DESTROYED,
	REMOVED,
	UPCOMING,
	NOT_AVAILABLE
}
