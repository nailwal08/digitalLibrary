package com.minor.project.entity;

public enum UserStatus {

	ACTIVE,
	INACTIVE,
	BLOCKED
}
