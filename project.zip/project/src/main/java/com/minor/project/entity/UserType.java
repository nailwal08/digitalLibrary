package com.minor.project.entity;

public enum UserType {

	STUDENT,
	ADMIN,
	FACULTY
}
