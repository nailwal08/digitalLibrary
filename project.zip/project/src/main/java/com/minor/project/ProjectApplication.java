/**
 * Model is Entity: Book, Author, UserInfo
 * Always use application.properties that we use in this project for mysql db.
 * also use MAVEN clean then MAVEN install to run the application.
 * Use this class to run this project
 */
package com.minor.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectApplication.class, args);
	}

}
