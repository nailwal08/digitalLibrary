package com.minor.project.entity;

public enum OrderStatus {

	PENDING, SUCCESS, ARCHIVE;
}
